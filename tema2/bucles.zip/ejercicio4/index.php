<?php
/*
 * @author David Castilla Ortiz
 */
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        div {
            height: 50px;
            width: 50px;
            display: inline-block;
        }
    </style>
    <title></title>
</head>

<body>
    <?php

    for ($red = 0; $red <= 255; $red += 5) {
        echo "<div style=\"background-color: rgb($red, $red, $red)\"></div>";
    }

    ?>
</body>

</html>
