<?php
/*
 * @author David Castilla Ortiz
 */
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
    <?php
    foreach (range(1, 10) as $i) {
        echo $i . " ";
    }
    ?>
</body>

</html>
